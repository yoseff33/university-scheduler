"use client";

import { AlertTriangle, ArrowLeft, Coffee, LoaderCircle, RefreshCw } from "lucide-react";
import type { ButtonHTMLAttributes, ReactNode } from "react";
import { clsx } from "clsx";
import { Link } from "react-router-dom";

export function Button({
  className,
  variant = "primary",
  busy,
  children,
  disabled,
  ...props
}: ButtonHTMLAttributes<HTMLButtonElement> & {
  variant?: "primary" | "secondary" | "ghost" | "danger";
  busy?: boolean;
}) {
  return (
    <button
      className={clsx("button", `button--${variant}`, className)}
      disabled={disabled || busy}
      {...props}
    >
      {busy && <LoaderCircle size={18} className="spin" aria-hidden />}
      {children}
    </button>
  );
}

export function Field({
  label,
  error,
  hint,
  children,
}: {
  label: string;
  error?: string;
  hint?: string;
  children: ReactNode;
}) {
  return (
    <label className="field">
      <span className="field__label">{label}</span>
      {children}
      {hint && !error && <small className="field__hint">{hint}</small>}
      {error && <small className="field__error">{error}</small>}
    </label>
  );
}

export function EmptyState({
  title,
  description,
  action,
}: {
  title: string;
  description: string;
  action?: ReactNode;
}) {
  return (
    <section className="empty-state">
      <span className="empty-state__mark"><Coffee size={26} /></span>
      <h2>{title}</h2>
      <p>{description}</p>
      {action}
    </section>
  );
}

export function ErrorState({
  message = "تعذر تحميل البيانات",
  onRetry,
}: {
  message?: string;
  onRetry?: () => void;
}) {
  return (
    <section className="empty-state empty-state--error" role="alert">
      <AlertTriangle size={28} />
      <h2>{message}</h2>
      <p>تحقق من اتصالك ثم حاول مرة أخرى.</p>
      {onRetry && (
        <Button variant="secondary" onClick={onRetry}>
          <RefreshCw size={17} /> إعادة المحاولة
        </Button>
      )}
    </section>
  );
}

export function PageHeader({
  eyebrow,
  title,
  description,
  backTo,
  action,
}: {
  eyebrow?: string;
  title: string;
  description?: string;
  backTo?: string;
  action?: ReactNode;
}) {
  return (
    <header className="page-header">
      <div className="page-header__copy">
        {backTo && (
          <Link to={backTo} className="back-link">
            <ArrowLeft size={17} /> رجوع
          </Link>
        )}
        {eyebrow && <span className="eyebrow">{eyebrow}</span>}
        <h1>{title}</h1>
        {description && <p>{description}</p>}
      </div>
      {action}
    </header>
  );
}

export function LoadingPage({ label = "جارٍ تحميل البيانات…" }: { label?: string }) {
  return (
    <main className="loading-page" role="status">
      <span className="brand-orbit"><Coffee size={30} /></span>
      <strong>{label}</strong>
    </main>
  );
}

export function StatusPill({ children, tone = "neutral" }: {
  children: ReactNode;
  tone?: "neutral" | "success" | "warning" | "danger" | "info";
}) {
  return <span className={`status-pill status-pill--${tone}`}>{children}</span>;
}

