"use client";

import {
  Bell,
  Coffee,
  LayoutDashboard,
  LogIn,
  Menu,
  Moon,
  Palette,
  ReceiptText,
  ShoppingBag,
  Stamp,
  Sun,
  UserRound,
  X,
} from "lucide-react";
import { useEffect, useState } from "react";
import { Link, NavLink, Outlet } from "react-router-dom";
import { useAuth, useCart } from "@/app/Providers";
import { getSupabase } from "@/lib/supabase";

const customerLinks = [
  { to: "/menu", label: "المنيو", icon: Coffee },
  { to: "/loyalty", label: "بطاقتي", icon: Stamp },
  { to: "/orders", label: "طلباتي", icon: ReceiptText },
  { to: "/profile", label: "حسابي", icon: UserRound },
];

export function AppShell() {
  const { session, profile, roles } = useAuth();
  const { items } = useCart();
  const [menuOpen, setMenuOpen] = useState(false);
  const [dark, setDark] = useState(false);
  const isStaff = roles.some((role) => role !== "customer");

  useEffect(() => {
    document.documentElement.dataset.theme = dark ? "dark" : "light";
  }, [dark]);

  return (
    <div className="app-shell">
      <header className="topbar">
        <Link to="/" className="brand" aria-label="الصفحة الرئيسية">
          <span className="brand__mark"><Coffee size={23} /></span>
          <span>
            <strong>مِرسى</strong>
            <small>قهوة تصل لعندك</small>
          </span>
        </Link>

        <nav className="desktop-nav" aria-label="التنقل الرئيسي">
          {customerLinks.slice(0, 3).map(({ to, label }) => (
                <NavLink key={to} to={to} onClick={() => setMenuOpen(false)}>{label}</NavLink>
          ))}
          {isStaff && <NavLink to="/admin">الإدارة</NavLink>}
        </nav>

        <div className="topbar__actions">
          <button className="icon-button" onClick={() => setDark((value) => !value)} aria-label="تبديل المظهر">
            {dark ? <Sun size={20} /> : <Moon size={20} />}
          </button>
          {session && (
            <Link className="icon-button" to="/notifications" aria-label="الإشعارات">
              <Bell size={20} />
            </Link>
          )}
          <Link className="cart-button" to="/cart" aria-label={`السلة، ${items.length} عناصر`}>
            <ShoppingBag size={20} />
            <span>{items.reduce((sum, item) => sum + item.quantity, 0)}</span>
          </Link>
          {session ? (
            <button
              className="profile-chip"
              onClick={() => void getSupabase().auth.signOut()}
              title="تسجيل الخروج"
            >
              <span>{profile?.full_name?.slice(0, 1) ?? "ع"}</span>
              <strong>{profile?.full_name?.split(" ")[0] ?? "حسابي"}</strong>
            </button>
          ) : (
            <Link to="/login" className="login-link"><LogIn size={18} /> دخول</Link>
          )}
          <button className="menu-toggle" onClick={() => setMenuOpen(true)} aria-label="فتح القائمة">
            <Menu size={23} />
          </button>
        </div>
      </header>

      {menuOpen && (
        <div className="drawer-backdrop" onClick={() => setMenuOpen(false)}>
          <aside className="drawer" onClick={(event) => event.stopPropagation()}>
            <div className="drawer__header">
              <span className="brand"><span className="brand__mark"><Coffee size={20} /></span><strong>مِرسى</strong></span>
              <button className="icon-button" onClick={() => setMenuOpen(false)} aria-label="إغلاق القائمة"><X size={20} /></button>
            </div>
            <nav>
              {customerLinks.map(({ to, label, icon: Icon }) => (
                <NavLink key={to} to={to} onClick={() => setMenuOpen(false)}><Icon size={19} /> {label}</NavLink>
              ))}
              <NavLink to="/card-editor" onClick={() => setMenuOpen(false)}><Palette size={19} /> زيّن بطاقتك</NavLink>
              {isStaff && <NavLink to="/admin" onClick={() => setMenuOpen(false)}><LayoutDashboard size={19} /> لوحة الإدارة</NavLink>}
            </nav>
          </aside>
        </div>
      )}

      <main className="page"><Outlet /></main>

      <nav className="mobile-nav" aria-label="التنقل السريع">
        {customerLinks.slice(0, 2).map(({ to, label, icon: Icon }) => (
          <NavLink key={to} to={to}><Icon size={20} /><span>{label}</span></NavLink>
        ))}
        <NavLink to="/cart" className="mobile-nav__cart">
          <span><ShoppingBag size={21} /><b>{items.reduce((sum, item) => sum + item.quantity, 0)}</b></span>
          <em>السلة</em>
        </NavLink>
        {customerLinks.slice(2).map(({ to, label, icon: Icon }) => (
          <NavLink key={to} to={to}><Icon size={20} /><span>{label}</span></NavLink>
        ))}
      </nav>

      <footer className="site-footer">
        <div><strong>مِرسى</strong><p>نظام طلب وولاء مصمم لتجربة قهوة سعودية أسرع.</p></div>
        <nav><Link to="/terms">الشروط</Link><Link to="/privacy">الخصوصية</Link><Link to="/marketing-consent">الموافقة التسويقية</Link></nav>
      </footer>
    </div>
  );
}
