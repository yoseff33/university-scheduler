import { CoffeeApp } from "../CoffeeApp";

export default function AppRoute() {
  return <CoffeeApp />;
}

