"use client";

import { createClient, type SupabaseClient } from "@supabase/supabase-js";

const url = process.env.NEXT_PUBLIC_SUPABASE_URL ?? "";
const anonKey = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY ?? "";

export const hasSupabaseConfig = Boolean(url && anonKey);

let singleton: SupabaseClient | null = null;

export function getSupabase() {
  if (!hasSupabaseConfig) {
    throw new Error("لم يتم ربط المشروع بـ Supabase بعد");
  }
  if (!singleton) {
    singleton = createClient(url, anonKey, {
      auth: {
        persistSession: true,
        autoRefreshToken: true,
        detectSessionInUrl: true,
        storage: typeof window === "undefined" ? undefined : window.sessionStorage,
      },
      realtime: { params: { eventsPerSecond: 10 } },
    });
  }
  return singleton;
}

export function publicAssetUrl(bucket: string, path?: string | null) {
  if (!path || !hasSupabaseConfig) return null;
  return getSupabase().storage.from(bucket).getPublicUrl(path).data.publicUrl;
}

