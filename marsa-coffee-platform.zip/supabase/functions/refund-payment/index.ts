import { z } from "npm:zod@4";
import { idempotencyKey, json, options, publicError } from "../_shared/http.ts";
import { adminClient, requirePermission } from "../_shared/supabase.ts";
import { refundAtProvider } from "../_shared/payments.ts";
import { uuid } from "../_shared/validators.ts";

const schema = z.object({
  payment_id: uuid,
  amount: z.number().positive(),
  reason: z.string().trim().min(4).max(500),
});

Deno.serve(async (req) => {
  const preflight = options(req);
  if (preflight) return preflight;
  if (req.method !== "POST") return json({ error: "الطريقة غير مسموحة" }, 405);
  const admin = adminClient();
  try {
    const key = idempotencyKey(req);
    const body = schema.parse(await req.json());
    const { data: existing } = await admin.from("refunds").select("*").eq("idempotency_key", key).maybeSingle();
    if (existing) return json({ refund: existing, replayed: true });
    const { data: payment, error } = await admin
      .from("payments")
      .select("id, order_id, provider_payment_id, amount, status, orders!inner(branch_id)")
      .eq("id", body.payment_id)
      .single();
    if (error || !payment) throw new Error("الدفعة غير موجودة");
    const branchId = (payment.orders as { branch_id: string }).branch_id;
    const { user } = await requirePermission(req, "payments.refund", branchId);
    if (payment.status !== "paid" && payment.status !== "partially_refunded") {
      throw new Error("الدفعة غير قابلة للاسترجاع");
    }
    if (body.amount > Number(payment.amount)) throw new Error("قيمة الاسترجاع تتجاوز قيمة الدفعة");
    const refundId = crypto.randomUUID();
    await admin.from("refunds").insert({
      id: refundId,
      payment_id: payment.id,
      order_id: payment.order_id,
      amount: body.amount,
      reason: body.reason,
      status: "pending",
      requested_by: user.id,
      idempotency_key: key,
    });
    const providerResult = await refundAtProvider({
      providerPaymentId: payment.provider_payment_id,
      amountMinor: Math.round(body.amount * 100),
    });
    const full = body.amount === Number(payment.amount);
    await admin.from("refunds").update({
      status: "succeeded",
      provider_refund_id: String(providerResult.id ?? ""),
      provider_response: providerResult,
    }).eq("id", refundId);
    await admin.from("payments").update({ status: full ? "refunded" : "partially_refunded" }).eq("id", payment.id);
    await admin.from("orders").update({ status: full ? "refunded" : "partially_refunded" }).eq("id", payment.order_id);
    await admin.from("order_status_history").insert({
      order_id: payment.order_id,
      from_status: "delivered",
      to_status: full ? "refunded" : "partially_refunded",
      changed_by: user.id,
      reason: body.reason,
    });
    return json({ refund_id: refundId, status: "succeeded", replayed: false });
  } catch (error) {
    console.error("refund-payment", error);
    return publicError(error);
  }
});

