import { z } from "npm:zod@4";
import { json, options, publicError } from "../_shared/http.ts";
import { adminClient, requireUser } from "../_shared/supabase.ts";

const schema = z.object({
  bucket: z.enum(["customer-assets", "exports"]),
  path: z.string().min(3).max(1000).refine((value) => !value.includes("..")),
  expires_in: z.number().int().min(60).max(3600).default(300),
});

Deno.serve(async (req) => {
  const preflight = options(req);
  if (preflight) return preflight;
  if (req.method !== "POST") return json({ error: "الطريقة غير مسموحة" }, 405);
  try {
    const body = schema.parse(await req.json());
    const { user } = await requireUser(req);
    if (!body.path.startsWith(`${user.id}/`)) {
      throw new Error("ليس لديك صلاحية للوصول إلى هذا الملف");
    }
    const { data, error } = await adminClient().storage
      .from(body.bucket)
      .createSignedUrl(body.path, body.expires_in);
    if (error) throw new Error("تعذر إصدار رابط الملف");
    return json({ signed_url: data.signedUrl, expires_in: body.expires_in });
  } catch (error) {
    console.error("signed-file-url", error);
    return publicError(error);
  }
});

