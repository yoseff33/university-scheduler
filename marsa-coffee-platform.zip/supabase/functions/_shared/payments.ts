import { requiredEnv } from "./http.ts";

export type ProviderPayment = {
  id: string;
  status: string;
  transactionUrl: string | null;
  raw: Record<string, unknown>;
};

function basicAuth(secret: string) {
  return `Basic ${btoa(`${secret}:`)}`;
}

export async function createPaymentAtProvider(input: {
  givenId: string;
  amountMinor: number;
  currency: string;
  orderNumber: string;
  orderId: string;
  callbackUrl: string;
  sourceToken: string;
}): Promise<ProviderPayment> {
  const provider = Deno.env.get("PAYMENT_PROVIDER") ?? "moyasar";
  const apiUrl = Deno.env.get("PAYMENT_API_URL") ??
    (provider === "moyasar" ? "https://api.moyasar.com/v1" : "");
  const secret = requiredEnv("PAYMENT_SECRET_KEY");
  if (!apiUrl) throw new Error("لم يتم تفعيل رابط بوابة الدفع");

  if (provider !== "moyasar") {
    throw new Error(`لم يتم تفعيل موائم بوابة الدفع: ${provider}`);
  }

  const response = await fetch(`${apiUrl.replace(/\/$/, "")}/payments`, {
    method: "POST",
    headers: {
      Authorization: basicAuth(secret),
      "Content-Type": "application/json",
      Accept: "application/json",
    },
    body: JSON.stringify({
      given_id: input.givenId,
      amount: input.amountMinor,
      currency: input.currency,
      description: `طلب ${input.orderNumber}`,
      callback_url: input.callbackUrl,
      source: { type: "token", token: input.sourceToken },
      metadata: { order_id: input.orderId, order_number: input.orderNumber },
    }),
  });
  const raw = await response.json().catch(() => ({})) as Record<string, unknown>;
  if (!response.ok) {
    console.error("payment provider create failed", response.status, raw);
    throw new Error("تعذر بدء الدفع لدى البوابة");
  }
  const source = raw.source as Record<string, unknown> | undefined;
  return {
    id: String(raw.id),
    status: String(raw.status),
    transactionUrl: typeof source?.transaction_url === "string"
      ? source.transaction_url
      : null,
    raw,
  };
}

export async function refundAtProvider(input: {
  providerPaymentId: string;
  amountMinor: number;
}) {
  const provider = Deno.env.get("PAYMENT_PROVIDER") ?? "moyasar";
  if (provider !== "moyasar") {
    throw new Error(`لم يتم تفعيل موائم الاسترجاع: ${provider}`);
  }
  const apiUrl = Deno.env.get("PAYMENT_API_URL") ?? "https://api.moyasar.com/v1";
  const response = await fetch(
    `${apiUrl.replace(/\/$/, "")}/payments/${encodeURIComponent(input.providerPaymentId)}/refund`,
    {
      method: "POST",
      headers: {
        Authorization: basicAuth(requiredEnv("PAYMENT_SECRET_KEY")),
        "Content-Type": "application/json",
        Accept: "application/json",
      },
      body: JSON.stringify({ amount: input.amountMinor }),
    },
  );
  const raw = await response.json().catch(() => ({})) as Record<string, unknown>;
  if (!response.ok) {
    console.error("payment provider refund failed", response.status, raw);
    throw new Error("رفضت بوابة الدفع عملية الاسترجاع");
  }
  return raw;
}

